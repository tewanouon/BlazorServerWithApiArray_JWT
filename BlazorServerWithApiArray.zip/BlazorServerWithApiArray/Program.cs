using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using BlazorServerWithApiArray.Services;
using BlazorServerWithApiArray.Models;

var builder = WebApplication.CreateBuilder(args);

// --- Services ---
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddHttpClient();
builder.Services.AddSingleton<ProductService>();

// AuthN + AuthZ (JWT Bearer)
var jwtSection = builder.Configuration.GetSection("Jwt");
var issuer = jwtSection["Issuer"];
var audience = jwtSection["Audience"];
var key = jwtSection["Key"]!;
var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateIssuerSigningKey = true,
        ValidateLifetime = true,
        ValidIssuer = issuer,
        ValidAudience = audience,
        IssuerSigningKey = signingKey,
        ClockSkew = TimeSpan.FromMinutes(1)
    };
});

builder.Services.AddAuthorization();

// Swagger + JWT support
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "API", Version = "v1" });
    var securityScheme = new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Description = "Enter 'Bearer {token}'",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
    };
    c.AddSecurityDefinition("Bearer", securityScheme);
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        { securityScheme, new string[] {} }
    });
});

builder.Services.AddCors(opt => { opt.AddPolicy("open", p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()); });

var app = builder.Build();

// Swagger always enabled
app.UseSwagger();
app.UseSwaggerUI();

app.UseStaticFiles();
app.UseRouting();

app.UseCors("open");
app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

// --------------------
// Auth endpoints
// --------------------
app.MapPost("/api/auth/login", (LoginRequest req) =>
{
    // DEMO only: hard-coded user
    if (req.Username == "admin" && req.Password == "P@ssw0rd")
    {
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, req.Username),
            new Claim(ClaimTypes.Name, req.Username),
            new Claim(ClaimTypes.Role, "Admin")
        };
        var creds = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: creds
        );
        var jwt = new JwtSecurityTokenHandler().WriteToken(token);
        return Results.Ok(new { access_token = jwt });
    }
    return Results.Unauthorized();
})
.WithTags("Auth");

// --------------------
// Minimal API (REST) - Protected
// --------------------
var api = app.MapGroup("/api/products").RequireAuthorization();

// GET all
api.MapGet("/", (ProductService svc) => Results.Ok(svc.GetAll())).WithTags("Products");

// GET by id
api.MapGet("/{id:int}", (int id, ProductService svc) => svc.GetById(id) is Product p ? Results.Ok(p) : Results.NotFound()).WithTags("Products");

// POST create
api.MapPost("/", (ProductCreate dto, ProductService svc) => {
    if (string.IsNullOrWhiteSpace(dto.Name)) return Results.BadRequest("Name is required");
    var created = svc.Create(dto.Name, dto.Price);
    return Results.Created($"/api/products/{created.Id}", created);
}).WithTags("Products");

// PUT update
api.MapPut("/{id:int}", (int id, ProductUpdate dto, ProductService svc) => svc.Update(id, dto.Name, dto.Price) ? Results.NoContent() : Results.NotFound()).WithTags("Products");

// DELETE
api.MapDelete("/{id:int}", (int id, ProductService svc) => svc.Delete(id) ? Results.NoContent() : Results.NotFound()).WithTags("Products");

app.Run();

public record ProductCreate(string Name, decimal Price);
public record ProductUpdate(string? Name, decimal? Price);
public record LoginRequest(string Username, string Password);
