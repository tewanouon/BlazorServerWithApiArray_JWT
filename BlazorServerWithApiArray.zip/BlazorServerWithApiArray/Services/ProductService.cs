using BlazorServerWithApiArray.Models;

namespace BlazorServerWithApiArray.Services;

public class ProductService
{
    private readonly List<Product> _items = new();
    private int _nextId = 1;
    private readonly object _lock = new();

    public ProductService()
    {
        _items.AddRange(new[]
        {
            new Product { Id = _nextId++, Name = "Monitor 27\"", Price = 7500 },
            new Product { Id = _nextId++, Name = "Keyboard", Price = 1200 },
        });
    }

    public IReadOnlyList<Product> GetAll()
    {
        lock (_lock)
        {
            return _items.Select(p => new Product { Id = p.Id, Name = p.Name, Price = p.Price }).ToList();
        }
    }

    public Product? GetById(int id)
    {
        lock (_lock)
        {
            var p = _items.FirstOrDefault(x => x.Id == id);
            return p is null ? null : new Product { Id = p.Id, Name = p.Name, Price = p.Price };
        }
    }

    public Product Create(string name, decimal price)
    {
        lock (_lock)
        {
            var p = new Product { Id = _nextId++, Name = name, Price = price };
            _items.Add(p);
            return new Product { Id = p.Id, Name = p.Name, Price = p.Price };
        }
    }

    public bool Update(int id, string? name, decimal? price)
    {
        lock (_lock)
        {
            var p = _items.FirstOrDefault(x => x.Id == id);
            if (p is null) return false;
            if (!string.IsNullOrWhiteSpace(name)) p.Name = name!;
            if (price.HasValue) p.Price = price.Value;
            return true;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock)
        {
            var p = _items.FirstOrDefault(x => x.Id == id);
            if (p is null) return false;
            _items.Remove(p);
            return true;
        }
    }
}
